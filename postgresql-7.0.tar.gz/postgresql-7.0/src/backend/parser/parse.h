typedef union
{
	int					ival;
	char				chr;
	char				*str;
	bool				boolean;
	List				*list;
	Node				*node;
	Value				*value;

	Attr				*attr;
	Ident				*ident;

	TypeName			*typnam;
	DefElem				*defelt;
	SortGroupBy			*sortgroupby;
	JoinExpr			*jexpr;
	IndexElem			*ielem;
	RangeVar			*range;
	RelExpr				*relexp;
	A_Indices			*aind;
	ResTarget			*target;
	ParamNo				*paramno;

	VersionStmt			*vstmt;
	DefineStmt			*dstmt;
	RuleStmt			*rstmt;
	InsertStmt			*astmt;
} YYSTYPE;
#define	ABSOLUTE	257
#define	ACTION	258
#define	ADD	259
#define	ALL	260
#define	ALTER	261
#define	AND	262
#define	ANY	263
#define	AS	264
#define	ASC	265
#define	BEGIN_TRANS	266
#define	BETWEEN	267
#define	BOTH	268
#define	BY	269
#define	CASCADE	270
#define	CASE	271
#define	CAST	272
#define	CHAR	273
#define	CHARACTER	274
#define	CHECK	275
#define	CLOSE	276
#define	COALESCE	277
#define	COLLATE	278
#define	COLUMN	279
#define	COMMIT	280
#define	CONSTRAINT	281
#define	CONSTRAINTS	282
#define	CREATE	283
#define	CROSS	284
#define	CURRENT	285
#define	CURRENT_DATE	286
#define	CURRENT_TIME	287
#define	CURRENT_TIMESTAMP	288
#define	CURRENT_USER	289
#define	CURSOR	290
#define	DAY_P	291
#define	DEC	292
#define	DECIMAL	293
#define	DECLARE	294
#define	DEFAULT	295
#define	DELETE	296
#define	DESC	297
#define	DISTINCT	298
#define	DOUBLE	299
#define	DROP	300
#define	ELSE	301
#define	END_TRANS	302
#define	EXCEPT	303
#define	EXECUTE	304
#define	EXISTS	305
#define	EXTRACT	306
#define	FALSE_P	307
#define	FETCH	308
#define	FLOAT	309
#define	FOR	310
#define	FOREIGN	311
#define	FROM	312
#define	FULL	313
#define	GLOBAL	314
#define	GRANT	315
#define	GROUP	316
#define	HAVING	317
#define	HOUR_P	318
#define	IN	319
#define	INNER_P	320
#define	INSENSITIVE	321
#define	INSERT	322
#define	INTERSECT	323
#define	INTERVAL	324
#define	INTO	325
#define	IS	326
#define	ISOLATION	327
#define	JOIN	328
#define	KEY	329
#define	LANGUAGE	330
#define	LEADING	331
#define	LEFT	332
#define	LEVEL	333
#define	LIKE	334
#define	LOCAL	335
#define	MATCH	336
#define	MINUTE_P	337
#define	MONTH_P	338
#define	NAMES	339
#define	NATIONAL	340
#define	NATURAL	341
#define	NCHAR	342
#define	NEXT	343
#define	NO	344
#define	NOT	345
#define	NULLIF	346
#define	NULL_P	347
#define	NUMERIC	348
#define	OF	349
#define	ON	350
#define	ONLY	351
#define	OPTION	352
#define	OR	353
#define	ORDER	354
#define	OUTER_P	355
#define	OVERLAPS	356
#define	PARTIAL	357
#define	POSITION	358
#define	PRECISION	359
#define	PRIMARY	360
#define	PRIOR	361
#define	PRIVILEGES	362
#define	PROCEDURE	363
#define	PUBLIC	364
#define	READ	365
#define	REFERENCES	366
#define	RELATIVE	367
#define	REVOKE	368
#define	RIGHT	369
#define	ROLLBACK	370
#define	SCROLL	371
#define	SECOND_P	372
#define	SELECT	373
#define	SESSION_USER	374
#define	SET	375
#define	SOME	376
#define	SUBSTRING	377
#define	TABLE	378
#define	TEMPORARY	379
#define	THEN	380
#define	TIME	381
#define	TIMESTAMP	382
#define	TIMEZONE_HOUR	383
#define	TIMEZONE_MINUTE	384
#define	TO	385
#define	TRAILING	386
#define	TRANSACTION	387
#define	TRIM	388
#define	TRUE_P	389
#define	UNION	390
#define	UNIQUE	391
#define	UPDATE	392
#define	USER	393
#define	USING	394
#define	VALUES	395
#define	VARCHAR	396
#define	VARYING	397
#define	VIEW	398
#define	WHEN	399
#define	WHERE	400
#define	WITH	401
#define	WORK	402
#define	YEAR_P	403
#define	ZONE	404
#define	DEFERRABLE	405
#define	DEFERRED	406
#define	IMMEDIATE	407
#define	INITIALLY	408
#define	PENDANT	409
#define	RESTRICT	410
#define	TRIGGER	411
#define	COMMITTED	412
#define	SERIALIZABLE	413
#define	TYPE_P	414
#define	ABORT_TRANS	415
#define	ACCESS	416
#define	AFTER	417
#define	AGGREGATE	418
#define	ANALYZE	419
#define	BACKWARD	420
#define	BEFORE	421
#define	BINARY	422
#define	BIT	423
#define	CACHE	424
#define	CLUSTER	425
#define	COMMENT	426
#define	COPY	427
#define	CREATEDB	428
#define	CREATEUSER	429
#define	CYCLE	430
#define	DATABASE	431
#define	DELIMITERS	432
#define	DO	433
#define	EACH	434
#define	ENCODING	435
#define	EXCLUSIVE	436
#define	EXPLAIN	437
#define	EXTEND	438
#define	FORCE	439
#define	FORWARD	440
#define	FUNCTION	441
#define	HANDLER	442
#define	INCREMENT	443
#define	INDEX	444
#define	INHERITS	445
#define	INSTEAD	446
#define	ISNULL	447
#define	LANCOMPILER	448
#define	LIMIT	449
#define	LISTEN	450
#define	LOAD	451
#define	LOCATION	452
#define	LOCK_P	453
#define	MAXVALUE	454
#define	MINVALUE	455
#define	MODE	456
#define	MOVE	457
#define	NEW	458
#define	NOCREATEDB	459
#define	NOCREATEUSER	460
#define	NONE	461
#define	NOTHING	462
#define	NOTIFY	463
#define	NOTNULL	464
#define	OFFSET	465
#define	OIDS	466
#define	OPERATOR	467
#define	PASSWORD	468
#define	PROCEDURAL	469
#define	REINDEX	470
#define	RENAME	471
#define	RESET	472
#define	RETURNS	473
#define	ROW	474
#define	RULE	475
#define	SEQUENCE	476
#define	SERIAL	477
#define	SETOF	478
#define	SHARE	479
#define	SHOW	480
#define	START	481
#define	STATEMENT	482
#define	STDIN	483
#define	STDOUT	484
#define	SYSID	485
#define	TEMP	486
#define	TRUNCATE	487
#define	TRUSTED	488
#define	UNLISTEN	489
#define	UNTIL	490
#define	VACUUM	491
#define	VALID	492
#define	VERBOSE	493
#define	VERSION	494
#define	IDENT	495
#define	FCONST	496
#define	SCONST	497
#define	Op	498
#define	ICONST	499
#define	PARAM	500
#define	OP	501
#define	UMINUS	502
#define	TYPECAST	503


extern YYSTYPE yylval;
