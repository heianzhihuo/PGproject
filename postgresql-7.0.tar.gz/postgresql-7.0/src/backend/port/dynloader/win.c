/* Dummy file used for nothing at this point
 *
 * see win.h
 */
