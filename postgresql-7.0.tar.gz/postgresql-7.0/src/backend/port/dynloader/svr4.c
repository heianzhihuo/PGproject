/* Dummy file used for nothing at this point
 *
 * see svr4.h
 */
