
/*  A Bison parser, made from bootparse.y
    by GNU Bison version 1.28  */

#define YYBISON 1  /* Identify Bison output.  */

#define	CONST	257
#define	ID	258
#define	OPEN	259
#define	XCLOSE	260
#define	XCREATE	261
#define	INSERT_TUPLE	262
#define	STRING	263
#define	XDEFINE	264
#define	XDECLARE	265
#define	INDEX	266
#define	ON	267
#define	USING	268
#define	XBUILD	269
#define	INDICES	270
#define	UNIQUE	271
#define	COMMA	272
#define	EQUALS	273
#define	LPAREN	274
#define	RPAREN	275
#define	OBJ_ID	276
#define	XBOOTSTRAP	277
#define	NULLVAL	278
#define	low	279
#define	high	280

#line 1 "bootparse.y"

/*-------------------------------------------------------------------------
 *
 * backendparse.y
 *	  yacc parser grammer for the "backend" initialization program.
 *
 * Portions Copyright (c) 1996-2000, PostgreSQL, Inc
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 *
 * IDENTIFICATION
 *	  $Header: /usr/local/cvsroot/pgsql/src/backend/bootstrap/bootparse.y,v 1.29 2000/01/26 05:56:07 momjian Exp $
 *
 *-------------------------------------------------------------------------
 */

#include <time.h>

#include "postgres.h"


#include "access/attnum.h"
#include "access/funcindex.h"
#include "access/htup.h"
#include "access/itup.h"
#include "access/skey.h"
#include "access/strat.h"
#include "access/tupdesc.h"
#include "access/xact.h"
#include "bootstrap/bootstrap.h"
#include "catalog/heap.h"
#include "catalog/pg_am.h"
#include "catalog/pg_attribute.h"
#include "catalog/pg_class.h"
#include "commands/defrem.h"
#include "miscadmin.h"
#include "nodes/nodes.h"
#include "nodes/parsenodes.h"
#include "nodes/pg_list.h"
#include "nodes/primnodes.h"
#include "rewrite/prs2lock.h"
#include "storage/block.h"
#include "storage/fd.h"
#include "storage/ipc.h"
#include "storage/itemptr.h"
#include "storage/off.h"
#include "storage/smgr.h"
#include "storage/spin.h"
#include "tcop/dest.h"
#include "utils/nabstime.h"
#include "utils/rel.h"

#define DO_START { \
					StartTransactionCommand();\
				 }

#define DO_END	 { \
					CommitTransactionCommand();\
					if (!Quiet) { EMITPROMPT; }\
						fflush(stdout); \
				 }

int num_tuples_read = 0;
static Oid objectid;


#line 68 "bootparse.y"
typedef union
{
	List		*list;
	IndexElem	*ielem;
	char		*str;
	int			ival;
} YYSTYPE;
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		77
#define	YYFLAG		-32768
#define	YYNTBASE	27

#define YYTRANSLATE(x) ((unsigned)(x) <= 280 ? Int_yytranslate[x] : 50)

static const char Int_yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     3,     4,     5,     6,
     7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
    17,    18,    19,    20,    21,    22,    23,    24,    25,    26
};

#if YYDEBUG != 0
static const short Int_yyprhs[] = {     0,
     0,     2,     3,     5,     8,    10,    12,    14,    16,    18,
    20,    22,    25,    28,    30,    31,    32,    41,    42,    49,
    60,    72,    75,    79,    81,    84,    86,    87,    89,    93,
    97,   101,   102,   104,   107,   111,   113,   115,   117,   119
};

static const short Int_yyrhs[] = {    28,
     0,     0,    29,     0,    28,    29,     0,    30,     0,    31,
     0,    32,     0,    35,     0,    37,     0,    38,     0,    39,
     0,     5,    49,     0,     6,    49,     0,     6,     0,     0,
     0,     7,    42,    49,    20,    33,    43,    34,    21,     0,
     0,     8,    45,    36,    20,    46,    21,     0,    11,    12,
    49,    13,    49,    14,    49,    20,    40,    21,     0,    11,
    17,    12,    49,    13,    49,    14,    49,    20,    40,    21,
     0,    15,    16,     0,    40,    18,    41,     0,    41,     0,
    49,    49,     0,    23,     0,     0,    44,     0,    43,    18,
    44,     0,    49,    19,    49,     0,    22,    19,    49,     0,
     0,    47,     0,    46,    47,     0,    46,    18,    47,     0,
    49,     0,    48,     0,    24,     0,     3,     0,     4,     0
};

#endif

#if YYDEBUG != 0
static const short Int_yyrline[] = { 0,
    94,    96,    99,   101,   104,   106,   107,   108,   109,   110,
   111,   114,   123,   130,   138,   145,   151,   191,   199,   222,
   235,   248,   252,   254,   257,   266,   268,   271,   273,   276,
   287,   289,   292,   294,   295,   298,   300,   301,   305,   309
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const Int_yytname[] = {   "$","error","$undefined.","CONST",
"ID","OPEN","XCLOSE","XCREATE","INSERT_TUPLE","STRING","XDEFINE","XDECLARE",
"INDEX","ON","USING","XBUILD","INDICES","UNIQUE","COMMA","EQUALS","LPAREN","RPAREN",
"OBJ_ID","XBOOTSTRAP","NULLVAL","low","high","TopLevel","Boot_Queries","Boot_Query",
"Boot_OpenStmt","Boot_CloseStmt","Boot_CreateStmt","@1","@2","Boot_InsertStmt",
"@3","Boot_DeclareIndexStmt","Boot_DeclareUniqueIndexStmt","Boot_BuildIndsStmt",
"boot_index_params","boot_index_param","optbootstrap","boot_typelist","boot_type_thing",
"optoideq","boot_tuplelist","boot_tuple","boot_const","boot_ident", NULL
};
#endif

static const short Int_yyr1[] = {     0,
    27,    27,    28,    28,    29,    29,    29,    29,    29,    29,
    29,    30,    31,    31,    33,    34,    32,    36,    35,    37,
    38,    39,    40,    40,    41,    42,    42,    43,    43,    44,
    45,    45,    46,    46,    46,    47,    47,    47,    48,    49
};

static const short Int_yyr2[] = {     0,
     1,     0,     1,     2,     1,     1,     1,     1,     1,     1,
     1,     2,     2,     1,     0,     0,     8,     0,     6,    10,
    11,     2,     3,     1,     2,     1,     0,     1,     3,     3,
     3,     0,     1,     2,     3,     1,     1,     1,     1,     1
};

static const short Int_yydefact[] = {     2,
     0,    14,    27,    32,     0,     0,     1,     3,     5,     6,
     7,     8,     9,    10,    11,    40,    12,    13,    26,     0,
     0,    18,     0,     0,    22,     4,     0,     0,     0,     0,
     0,    15,    31,     0,     0,     0,     0,    39,    38,     0,
    33,    37,    36,     0,     0,    16,    28,     0,     0,    19,
    34,     0,     0,     0,     0,     0,    35,     0,     0,    29,
    17,    30,     0,     0,     0,    24,     0,     0,     0,    20,
    25,     0,    23,    21,     0,     0,     0
};

static const short Int_yydefgoto[] = {    75,
     7,     8,     9,    10,    11,    37,    55,    12,    29,    13,
    14,    15,    65,    66,    20,    46,    47,    22,    40,    41,
    42,    43
};

static const short Int_yypact[] = {     5,
    10,    10,   -14,    -7,   -10,    15,     5,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    10,
     4,-32768,    10,    21,-32768,-32768,    17,    10,    18,    22,
    10,-32768,-32768,     2,    10,    26,    10,-32768,-32768,     0,
-32768,-32768,-32768,    27,    10,    24,-32768,    28,     2,-32768,
-32768,    10,    29,    10,    19,    10,-32768,    25,    10,-32768,
-32768,-32768,    10,    30,     7,-32768,    10,    10,    10,-32768,
-32768,    11,-32768,-32768,    46,    48,-32768
};

static const short Int_yypgoto[] = {-32768,
-32768,    42,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,   -16,   -15,-32768,-32768,     3,-32768,-32768,   -32,
-32768,    -1
};


#define	YYLAST		68


static const short Int_yytable[] = {    17,
    18,    23,    38,    16,    38,    16,    24,    51,    19,     1,
     2,     3,     4,    16,    21,     5,    57,    49,    27,     6,
    50,    30,    28,    39,    69,    39,    33,    70,    69,    36,
    25,    74,    31,    44,    35,    48,    32,    34,    45,    61,
    52,    54,    59,    53,    63,    76,    56,    77,    26,    68,
    58,    72,    48,    73,    62,     0,    60,    64,     0,     0,
     0,    67,     0,     0,     0,    71,    67,    67
};

static const short Int_yycheck[] = {     1,
     2,    12,     3,     4,     3,     4,    17,    40,    23,     5,
     6,     7,     8,     4,    22,    11,    49,    18,    20,    15,
    21,    23,    19,    24,    18,    24,    28,    21,    18,    31,
    16,    21,    12,    35,    13,    37,    20,    20,    13,    21,
    14,    18,    14,    45,    20,     0,    19,     0,     7,    20,
    52,    68,    54,    69,    56,    -1,    54,    59,    -1,    -1,
    -1,    63,    -1,    -1,    -1,    67,    68,    69
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/misc/bison.simple"
/* This file comes from bison-1.28.  */

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

#ifndef YYSTACK_USE_ALLOCA
#ifdef alloca
#define YYSTACK_USE_ALLOCA
#else /* alloca not defined */
#ifdef __GNUC__
#define YYSTACK_USE_ALLOCA
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi) || (defined (__sun) && defined (__i386))
#define YYSTACK_USE_ALLOCA
#include <alloca.h>
#else /* not sparc */
/* We think this test detects Watcom and Microsoft C.  */
/* This used to test MSDOS, but that is a bad idea
   since that symbol is in the user namespace.  */
#if (defined (_MSDOS) || defined (_MSDOS_)) && !defined (__TURBOC__)
#if 0 /* No need for malloc.h, which pollutes the namespace;
	 instead, just don't use alloca.  */
#include <malloc.h>
#endif
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
/* I don't know what this was needed for, but it pollutes the namespace.
   So I turned it off.   rms, 2 May 1997.  */
/* #include <malloc.h>  */
 #pragma alloca
#define YYSTACK_USE_ALLOCA
#else /* not MSDOS, or __TURBOC__, or _AIX */
#if 0
#ifdef __hpux /* haible@ilog.fr says this works for HPUX 9.05 and up,
		 and on HPUX 10.  Eventually we can turn this on.  */
#define YYSTACK_USE_ALLOCA
#define alloca __builtin_alloca
#endif /* __hpux */
#endif
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc */
#endif /* not GNU C */
#endif /* alloca not defined */
#endif /* YYSTACK_USE_ALLOCA not defined */

#ifdef YYSTACK_USE_ALLOCA
#define YYSTACK_ALLOC alloca
#else
#define YYSTACK_ALLOC malloc
#endif

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define Int_yyerrok		(Int_yyerrstatus = 0)
#define Int_yyclearin	(Int_yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto Int_yyacceptlab
#define YYABORT 	goto Int_yyabortlab
#define YYERROR		goto Int_yyerrlab1
/* Like YYERROR except do call Int_yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto Int_yyerrlab
#define YYRECOVERING()  (!!Int_yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (Int_yychar == YYEMPTY && Int_yylen == 1)				\
    { Int_yychar = (token), Int_yylval = (value);			\
      Int_yychar1 = YYTRANSLATE (Int_yychar);				\
      YYPOPSTACK;						\
      goto Int_yybackup;						\
    }								\
  else								\
    { Int_yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		Int_yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		Int_yylex(&Int_yylval, &Int_yylloc, YYLEX_PARAM)
#else
#define YYLEX		Int_yylex(&Int_yylval, &Int_yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		Int_yylex(&Int_yylval, YYLEX_PARAM)
#else
#define YYLEX		Int_yylex(&Int_yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	Int_yychar;			/*  the lookahead symbol		*/
YYSTYPE	Int_yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE Int_yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int Int_yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int Int_yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Define __yy_memcpy.  Note that the size argument
   should be passed with type unsigned int, because that is what the non-GCC
   definitions require.  With GCC, __builtin_memcpy takes an arg
   of type size_t, but it can handle unsigned int.  */

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     unsigned int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, unsigned int count)
{
  register char *t = to;
  register char *f = from;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 217 "/usr/share/misc/bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into Int_yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
#ifdef YYPARSE_PARAM
int Int_yyparse (void *);
#else
int Int_yyparse (void);
#endif
#endif

int
Int_yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int Int_yystate;
  register int Int_yyn;
  register short *Int_yyssp;
  register YYSTYPE *Int_yyvsp;
  int Int_yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int Int_yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	Int_yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE Int_yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *Int_yyss = Int_yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *Int_yyvs = Int_yyvsa;	/*  to allow Int_yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE Int_yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *Int_yyls = Int_yylsa;
  YYLTYPE *Int_yylsp;

#define YYPOPSTACK   (Int_yyvsp--, Int_yyssp--, Int_yylsp--)
#else
#define YYPOPSTACK   (Int_yyvsp--, Int_yyssp--)
#endif

  int Int_yystacksize = YYINITDEPTH;
  int Int_yyfree_stacks = 0;

#ifdef YYPURE
  int Int_yychar;
  YYSTYPE Int_yylval;
  int Int_yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE Int_yylloc;
#endif
#endif

  YYSTYPE Int_yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int Int_yylen;

#if YYDEBUG != 0
  if (Int_yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  Int_yystate = 0;
  Int_yyerrstatus = 0;
  Int_yynerrs = 0;
  Int_yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  Int_yyssp = Int_yyss - 1;
  Int_yyvsp = Int_yyvs;
#ifdef YYLSP_NEEDED
  Int_yylsp = Int_yyls;
#endif

/* Push a new state, which is found in  Int_yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
Int_yynewstate:

  *++Int_yyssp = Int_yystate;

  if (Int_yyssp >= Int_yyss + Int_yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *Int_yyvs1 = Int_yyvs;
      short *Int_yyss1 = Int_yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *Int_yyls1 = Int_yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = Int_yyssp - Int_yyss + 1;

#ifdef Int_yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if Int_yyoverflow is a macro.  */
      Int_yyoverflow("parser stack overflow",
		 &Int_yyss1, size * sizeof (*Int_yyssp),
		 &Int_yyvs1, size * sizeof (*Int_yyvsp),
		 &Int_yyls1, size * sizeof (*Int_yylsp),
		 &Int_yystacksize);
#else
      Int_yyoverflow("parser stack overflow",
		 &Int_yyss1, size * sizeof (*Int_yyssp),
		 &Int_yyvs1, size * sizeof (*Int_yyvsp),
		 &Int_yystacksize);
#endif

      Int_yyss = Int_yyss1; Int_yyvs = Int_yyvs1;
#ifdef YYLSP_NEEDED
      Int_yyls = Int_yyls1;
#endif
#else /* no Int_yyoverflow */
      /* Extend the stack our own way.  */
      if (Int_yystacksize >= YYMAXDEPTH)
	{
	  Int_yyerror("parser stack overflow");
	  if (Int_yyfree_stacks)
	    {
	      free (Int_yyss);
	      free (Int_yyvs);
#ifdef YYLSP_NEEDED
	      free (Int_yyls);
#endif
	    }
	  return 2;
	}
      Int_yystacksize *= 2;
      if (Int_yystacksize > YYMAXDEPTH)
	Int_yystacksize = YYMAXDEPTH;
#ifndef YYSTACK_USE_ALLOCA
      Int_yyfree_stacks = 1;
#endif
      Int_yyss = (short *) YYSTACK_ALLOC (Int_yystacksize * sizeof (*Int_yyssp));
      __yy_memcpy ((char *)Int_yyss, (char *)Int_yyss1,
		   size * (unsigned int) sizeof (*Int_yyssp));
      Int_yyvs = (YYSTYPE *) YYSTACK_ALLOC (Int_yystacksize * sizeof (*Int_yyvsp));
      __yy_memcpy ((char *)Int_yyvs, (char *)Int_yyvs1,
		   size * (unsigned int) sizeof (*Int_yyvsp));
#ifdef YYLSP_NEEDED
      Int_yyls = (YYLTYPE *) YYSTACK_ALLOC (Int_yystacksize * sizeof (*Int_yylsp));
      __yy_memcpy ((char *)Int_yyls, (char *)Int_yyls1,
		   size * (unsigned int) sizeof (*Int_yylsp));
#endif
#endif /* no Int_yyoverflow */

      Int_yyssp = Int_yyss + size - 1;
      Int_yyvsp = Int_yyvs + size - 1;
#ifdef YYLSP_NEEDED
      Int_yylsp = Int_yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (Int_yydebug)
	fprintf(stderr, "Stack size increased to %d\n", Int_yystacksize);
#endif

      if (Int_yyssp >= Int_yyss + Int_yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (Int_yydebug)
    fprintf(stderr, "Entering state %d\n", Int_yystate);
#endif

  goto Int_yybackup;
 Int_yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* Int_yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  Int_yyn = Int_yypact[Int_yystate];
  if (Int_yyn == YYFLAG)
    goto Int_yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* Int_yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (Int_yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (Int_yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      Int_yychar = YYLEX;
    }

  /* Convert token to internal form (in Int_yychar1) for indexing tables with */

  if (Int_yychar <= 0)		/* This means end of input. */
    {
      Int_yychar1 = 0;
      Int_yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (Int_yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      Int_yychar1 = YYTRANSLATE(Int_yychar);

#if YYDEBUG != 0
      if (Int_yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", Int_yychar, Int_yytname[Int_yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, Int_yychar, Int_yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  Int_yyn += Int_yychar1;
  if (Int_yyn < 0 || Int_yyn > YYLAST || Int_yycheck[Int_yyn] != Int_yychar1)
    goto Int_yydefault;

  Int_yyn = Int_yytable[Int_yyn];

  /* Int_yyn is what to do for this token type in this state.
     Negative => reduce, -Int_yyn is rule number.
     Positive => shift, Int_yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (Int_yyn < 0)
    {
      if (Int_yyn == YYFLAG)
	goto Int_yyerrlab;
      Int_yyn = -Int_yyn;
      goto Int_yyreduce;
    }
  else if (Int_yyn == 0)
    goto Int_yyerrlab;

  if (Int_yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (Int_yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", Int_yychar, Int_yytname[Int_yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (Int_yychar != YYEOF)
    Int_yychar = YYEMPTY;

  *++Int_yyvsp = Int_yylval;
#ifdef YYLSP_NEEDED
  *++Int_yylsp = Int_yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (Int_yyerrstatus) Int_yyerrstatus--;

  Int_yystate = Int_yyn;
  goto Int_yynewstate;

/* Do the default action for the current state.  */
Int_yydefault:

  Int_yyn = Int_yydefact[Int_yystate];
  if (Int_yyn == 0)
    goto Int_yyerrlab;

/* Do a reduction.  Int_yyn is the number of a rule to reduce with.  */
Int_yyreduce:
  Int_yylen = Int_yyr2[Int_yyn];
  if (Int_yylen > 0)
    Int_yyval = Int_yyvsp[1-Int_yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (Int_yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       Int_yyn, Int_yyrline[Int_yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = Int_yyprhs[Int_yyn]; Int_yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", Int_yytname[Int_yyrhs[i]]);
      fprintf (stderr, " -> %s\n", Int_yytname[Int_yyr1[Int_yyn]]);
    }
#endif


  switch (Int_yyn) {

case 12:
#line 116 "bootparse.y"
{
					DO_START;
					boot_openrel(LexIDStr(Int_yyvsp[0].ival));
					DO_END;
				;
    break;}
case 13:
#line 125 "bootparse.y"
{
					DO_START;
					closerel(LexIDStr(Int_yyvsp[0].ival));
					DO_END;
				;
    break;}
case 14:
#line 131 "bootparse.y"
{
					DO_START;
					closerel(NULL);
					DO_END;
				;
    break;}
case 15:
#line 140 "bootparse.y"
{
					DO_START;
					numattr=(int)0;
				;
    break;}
case 16:
#line 145 "bootparse.y"
{
					if (!Quiet)
						putchar('\n');
					DO_END;
				;
    break;}
case 17:
#line 151 "bootparse.y"
{
					DO_START;

					if (Int_yyvsp[-6].ival)
					{
						extern Relation reldesc;
						TupleDesc tupdesc;

						if (reldesc)
						{
							puts("create bootstrap: Warning, open relation");
							puts("exists, closing first");
							closerel(NULL);
						}
						if (DebugMode)
							puts("creating bootstrap relation");
						tupdesc = CreateTupleDesc(numattr,attrtypes);
						reldesc = heap_create(LexIDStr(Int_yyvsp[-5].ival), tupdesc,
											  false, false, true);
						if (DebugMode)
							puts("bootstrap relation created ok");
					}
					else
					{
						Oid id;
						TupleDesc tupdesc;

						tupdesc = CreateTupleDesc(numattr,attrtypes);
						id = heap_create_with_catalog(LexIDStr(Int_yyvsp[-5].ival),
											tupdesc, RELKIND_RELATION, false);
						if (!Quiet)
							printf("CREATED relation %s with OID %u\n",
								   LexIDStr(Int_yyvsp[-5].ival), id);
					}
					DO_END;
					if (DebugMode)
						puts("Commit End");
				;
    break;}
case 18:
#line 193 "bootparse.y"
{
					DO_START;
					if (DebugMode)
						printf("tuple %d<", Int_yyvsp[0].ival);
					num_tuples_read = 0;
				;
    break;}
case 19:
#line 200 "bootparse.y"
{
					if (num_tuples_read != numattr)
						elog(ERROR,"incorrect number of values for tuple");
					if (reldesc == (Relation)NULL)
					{
						elog(ERROR,"must OPEN RELATION before INSERT\n");
						err_out();
					}
					if (DebugMode)
						puts("Insert Begin");
					objectid = Int_yyvsp[-4].ival;
					InsertOneTuple(objectid);
					if (DebugMode)
						puts("Insert End");
					if (!Quiet)
						putchar('\n');
					DO_END;
					if (DebugMode)
						puts("Transaction End");
				;
    break;}
case 20:
#line 224 "bootparse.y"
{
					DO_START;

					DefineIndex(LexIDStr(Int_yyvsp[-5].ival),
								LexIDStr(Int_yyvsp[-7].ival),
								LexIDStr(Int_yyvsp[-3].ival),
								Int_yyvsp[-1].list, NIL, 0, 0, 0, NIL);
					DO_END;
				;
    break;}
case 21:
#line 237 "bootparse.y"
{
					DO_START;

					DefineIndex(LexIDStr(Int_yyvsp[-5].ival),
								LexIDStr(Int_yyvsp[-7].ival),
								LexIDStr(Int_yyvsp[-3].ival),
								Int_yyvsp[-1].list, NIL, 1, 0, 0, NIL);
					DO_END;
				;
    break;}
case 22:
#line 249 "bootparse.y"
{ build_indices(); ;
    break;}
case 23:
#line 253 "bootparse.y"
{ Int_yyval.list = lappend(Int_yyvsp[-2].list, Int_yyvsp[0].ielem); ;
    break;}
case 24:
#line 254 "bootparse.y"
{ Int_yyval.list = lcons(Int_yyvsp[0].ielem, NIL); ;
    break;}
case 25:
#line 259 "bootparse.y"
{
					IndexElem *n = makeNode(IndexElem);
					n->name = LexIDStr(Int_yyvsp[-1].ival);
					n->class = LexIDStr(Int_yyvsp[0].ival);
					Int_yyval.ielem = n;
				;
    break;}
case 26:
#line 267 "bootparse.y"
{ Int_yyval.ival = 1; ;
    break;}
case 27:
#line 268 "bootparse.y"
{ Int_yyval.ival = 0; ;
    break;}
case 30:
#line 278 "bootparse.y"
{
				   if(++numattr > MAXATTR)
						elog(FATAL,"Too many attributes\n");
				   DefineAttr(LexIDStr(Int_yyvsp[-2].ival),LexIDStr(Int_yyvsp[0].ival),numattr-1);
				   if (DebugMode)
					   printf("\n");
				;
    break;}
case 31:
#line 288 "bootparse.y"
{ Int_yyval.ival = atol(LexIDStr(Int_yyvsp[0].ival));				;
    break;}
case 32:
#line 289 "bootparse.y"
{ extern Oid newoid(); Int_yyval.ival = newoid();	;
    break;}
case 36:
#line 299 "bootparse.y"
{InsertOneValue(objectid, LexIDStr(Int_yyvsp[0].ival), num_tuples_read++); ;
    break;}
case 37:
#line 300 "bootparse.y"
{InsertOneValue(objectid, LexIDStr(Int_yyvsp[0].ival), num_tuples_read++); ;
    break;}
case 38:
#line 302 "bootparse.y"
{ InsertOneNull(num_tuples_read++); ;
    break;}
case 39:
#line 306 "bootparse.y"
{ Int_yyval.ival=Int_yylval.ival; ;
    break;}
case 40:
#line 310 "bootparse.y"
{ Int_yyval.ival=Int_yylval.ival; ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 543 "/usr/share/misc/bison.simple"

  Int_yyvsp -= Int_yylen;
  Int_yyssp -= Int_yylen;
#ifdef YYLSP_NEEDED
  Int_yylsp -= Int_yylen;
#endif

#if YYDEBUG != 0
  if (Int_yydebug)
    {
      short *ssp1 = Int_yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != Int_yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++Int_yyvsp = Int_yyval;

#ifdef YYLSP_NEEDED
  Int_yylsp++;
  if (Int_yylen == 0)
    {
      Int_yylsp->first_line = Int_yylloc.first_line;
      Int_yylsp->first_column = Int_yylloc.first_column;
      Int_yylsp->last_line = (Int_yylsp-1)->last_line;
      Int_yylsp->last_column = (Int_yylsp-1)->last_column;
      Int_yylsp->text = 0;
    }
  else
    {
      Int_yylsp->last_line = (Int_yylsp+Int_yylen-1)->last_line;
      Int_yylsp->last_column = (Int_yylsp+Int_yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  Int_yyn = Int_yyr1[Int_yyn];

  Int_yystate = Int_yypgoto[Int_yyn - YYNTBASE] + *Int_yyssp;
  if (Int_yystate >= 0 && Int_yystate <= YYLAST && Int_yycheck[Int_yystate] == *Int_yyssp)
    Int_yystate = Int_yytable[Int_yystate];
  else
    Int_yystate = Int_yydefgoto[Int_yyn - YYNTBASE];

  goto Int_yynewstate;

Int_yyerrlab:   /* here on detecting error */

  if (! Int_yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++Int_yynerrs;

#ifdef YYERROR_VERBOSE
      Int_yyn = Int_yypact[Int_yystate];

      if (Int_yyn > YYFLAG && Int_yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -Int_yyn if nec to avoid negative indexes in Int_yycheck.  */
	  for (x = (Int_yyn < 0 ? -Int_yyn : 0);
	       x < (sizeof(Int_yytname) / sizeof(char *)); x++)
	    if (Int_yycheck[x + Int_yyn] == x)
	      size += strlen(Int_yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (Int_yyn < 0 ? -Int_yyn : 0);
		       x < (sizeof(Int_yytname) / sizeof(char *)); x++)
		    if (Int_yycheck[x + Int_yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, Int_yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      Int_yyerror(msg);
	      free(msg);
	    }
	  else
	    Int_yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	Int_yyerror("parse error");
    }

  goto Int_yyerrlab1;
Int_yyerrlab1:   /* here on error raised explicitly by an action */

  if (Int_yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (Int_yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (Int_yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", Int_yychar, Int_yytname[Int_yychar1]);
#endif

      Int_yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  Int_yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto Int_yyerrhandle;

Int_yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  Int_yyn = Int_yydefact[Int_yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (Int_yyn) goto Int_yydefault;
#endif

Int_yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (Int_yyssp == Int_yyss) YYABORT;
  Int_yyvsp--;
  Int_yystate = *--Int_yyssp;
#ifdef YYLSP_NEEDED
  Int_yylsp--;
#endif

#if YYDEBUG != 0
  if (Int_yydebug)
    {
      short *ssp1 = Int_yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != Int_yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

Int_yyerrhandle:

  Int_yyn = Int_yypact[Int_yystate];
  if (Int_yyn == YYFLAG)
    goto Int_yyerrdefault;

  Int_yyn += YYTERROR;
  if (Int_yyn < 0 || Int_yyn > YYLAST || Int_yycheck[Int_yyn] != YYTERROR)
    goto Int_yyerrdefault;

  Int_yyn = Int_yytable[Int_yyn];
  if (Int_yyn < 0)
    {
      if (Int_yyn == YYFLAG)
	goto Int_yyerrpop;
      Int_yyn = -Int_yyn;
      goto Int_yyreduce;
    }
  else if (Int_yyn == 0)
    goto Int_yyerrpop;

  if (Int_yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (Int_yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++Int_yyvsp = Int_yylval;
#ifdef YYLSP_NEEDED
  *++Int_yylsp = Int_yylloc;
#endif

  Int_yystate = Int_yyn;
  goto Int_yynewstate;

 Int_yyacceptlab:
  /* YYACCEPT comes here.  */
  if (Int_yyfree_stacks)
    {
      free (Int_yyss);
      free (Int_yyvs);
#ifdef YYLSP_NEEDED
      free (Int_yyls);
#endif
    }
  return 0;

 Int_yyabortlab:
  /* YYABORT comes here.  */
  if (Int_yyfree_stacks)
    {
      free (Int_yyss);
      free (Int_yyvs);
#ifdef YYLSP_NEEDED
      free (Int_yyls);
#endif
    }
  return 1;
}
#line 312 "bootparse.y"

