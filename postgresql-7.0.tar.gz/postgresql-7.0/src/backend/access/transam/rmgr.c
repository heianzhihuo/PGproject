#include "postgres.h"
#include "access/rmgr.h"

RmgrData   *RmgrTable = NULL;
