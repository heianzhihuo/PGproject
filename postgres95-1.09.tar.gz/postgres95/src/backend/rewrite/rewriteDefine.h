/*-------------------------------------------------------------------------
 *
 * rewriteDefine.h--
 *    
 *
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 * $Id: rewriteDefine.h,v 1.1.1.1 1996/07/09 06:21:51 scrappy Exp $
 *
 *-------------------------------------------------------------------------
 */
#ifndef	REWRITEDEFINE_H
#define	REWRITEDEFINE_H

extern void DefineQueryRewrite(RuleStmt *args); 

#endif	/* REWRITEDEFINE_H */
