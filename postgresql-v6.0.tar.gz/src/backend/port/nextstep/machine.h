#ifndef MACHINE_H
#define MACHINE_H

#define BLCKSZ	8192

#endif
